#!/usr/bin/env python3
"""
SecurePass Toolkit
A small Python application for generating secure passwords and checking password strength.
Designed as a mini project for a professional development portfolio.
"""

from __future__ import annotations

import math
import re
import secrets
import string
from dataclasses import dataclass


@dataclass
class StrengthResult:
    score: int
    rating: str
    entropy_bits: float
    feedback: list[str]


class PasswordToolkit:
    def __init__(self) -> None:
        self.lowercase = string.ascii_lowercase
        self.uppercase = string.ascii_uppercase
        self.digits = string.digits
        self.symbols = "!@#$%^&*()-_=+[]{};:,.?/"

    def generate_password(
        self,
        length: int = 12,
        use_upper: bool = True,
        use_lower: bool = True,
        use_digits: bool = True,
        use_symbols: bool = True,
    ) -> str:
        if length < 4:
            raise ValueError("Password length must be at least 4.")

        character_groups: list[str] = []
        guaranteed_chars: list[str] = []

        if use_upper:
            character_groups.append(self.uppercase)
            guaranteed_chars.append(secrets.choice(self.uppercase))
        if use_lower:
            character_groups.append(self.lowercase)
            guaranteed_chars.append(secrets.choice(self.lowercase))
        if use_digits:
            character_groups.append(self.digits)
            guaranteed_chars.append(secrets.choice(self.digits))
        if use_symbols:
            character_groups.append(self.symbols)
            guaranteed_chars.append(secrets.choice(self.symbols))

        if not character_groups:
            raise ValueError("At least one character set must be selected.")

        all_chars = "".join(character_groups)
        remaining = [secrets.choice(all_chars) for _ in range(length - len(guaranteed_chars))]
        password_list = guaranteed_chars + remaining
        secrets.SystemRandom().shuffle(password_list)
        return "".join(password_list)

    def check_strength(self, password: str) -> StrengthResult:
        if not password:
            return StrengthResult(0, "Very Weak", 0.0, ["Password cannot be empty."])

        score = 0
        feedback: list[str] = []

        has_lower = bool(re.search(r"[a-z]", password))
        has_upper = bool(re.search(r"[A-Z]", password))
        has_digit = bool(re.search(r"\d", password))
        has_symbol = bool(re.search(r"[^A-Za-z0-9]", password))

        pool_size = 0
        if has_lower:
            pool_size += 26
        if has_upper:
            pool_size += 26
        if has_digit:
            pool_size += 10
        if has_symbol:
            pool_size += len(self.symbols)

        entropy = len(password) * math.log2(pool_size) if pool_size else 0.0

        # Length scoring
        if len(password) >= 12:
            score += 3
        elif len(password) >= 8:
            score += 2
        else:
            feedback.append("Use at least 12 characters.")

        # Character variety scoring
        variety = sum([has_lower, has_upper, has_digit, has_symbol])
        score += variety

        if not has_lower:
            feedback.append("Add lowercase letters.")
        if not has_upper:
            feedback.append("Add uppercase letters.")
        if not has_digit:
            feedback.append("Add numbers.")
        if not has_symbol:
            feedback.append("Add symbols.")

        # Common pattern penalties
        lower_pw = password.lower()
        weak_patterns = [
            "password",
            "1234",
            "qwerty",
            "admin",
            "letmein",
            "welcome",
        ]
        if any(pattern in lower_pw for pattern in weak_patterns):
            score -= 2
            feedback.append("Avoid common words or predictable patterns.")

        if re.search(r"(.)\1\1", password):
            score -= 1
            feedback.append("Avoid repeated characters.")

        if re.search(r"0123|1234|2345|3456|4567|5678|6789", password):
            score -= 1
            feedback.append("Avoid sequential numbers.")

        if score <= 2:
            rating = "Very Weak"
        elif score <= 4:
            rating = "Weak"
        elif score <= 6:
            rating = "Moderate"
        elif score <= 7:
            rating = "Strong"
        else:
            rating = "Very Strong"

        if not feedback:
            feedback.append("Good password hygiene detected.")

        return StrengthResult(max(score, 0), rating, round(entropy, 2), feedback)


def print_menu() -> None:
    print("\n=== SecurePass Toolkit ===")
    print("1. Generate a secure password")
    print("2. Check password strength")
    print("3. Exit")


def prompt_yes_no(message: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    answer = input(f"{message} {suffix}: ").strip().lower()
    if not answer:
        return default
    return answer in {"y", "yes"}


def handle_generation(toolkit: PasswordToolkit) -> None:
    try:
        length = int(input("Enter password length (recommended 12 or more): ").strip())
        use_upper = prompt_yes_no("Include uppercase letters?", True)
        use_lower = prompt_yes_no("Include lowercase letters?", True)
        use_digits = prompt_yes_no("Include digits?", True)
        use_symbols = prompt_yes_no("Include symbols?", True)

        password = toolkit.generate_password(
            length=length,
            use_upper=use_upper,
            use_lower=use_lower,
            use_digits=use_digits,
            use_symbols=use_symbols,
        )
        print(f"\nGenerated password: {password}")
    except ValueError as exc:
        print(f"Error: {exc}")


def handle_strength_check(toolkit: PasswordToolkit) -> None:
    password = input("Enter the password to analyse: ").strip()
    result = toolkit.check_strength(password)
    print("\n--- Password Analysis ---")
    print(f"Rating: {result.rating}")
    print(f"Score: {result.score}/8")
    print(f"Estimated entropy: {result.entropy_bits} bits")
    print("Feedback:")
    for item in result.feedback:
        print(f"- {item}")


def main() -> None:
    toolkit = PasswordToolkit()

    while True:
        print_menu()
        choice = input("Choose an option: ").strip()

        if choice == "1":
            handle_generation(toolkit)
        elif choice == "2":
            handle_strength_check(toolkit)
        elif choice == "3":
            print("Goodbye.")
            break
        else:
            print("Invalid option. Please choose 1, 2, or 3.")


if __name__ == "__main__":
    main()
