# Mini Project Report – SecurePass Toolkit

## 1. Project Title
SecurePass Toolkit: Password Generator and Strength Checker

## 2. Project Aim
The aim of this mini project is to develop a Python application that helps users create stronger passwords and evaluate password strength. The project supports both programming skill development and cybersecurity awareness.

## 3. Objectives
- Build a working Python command-line application
- Apply core programming concepts such as functions, classes, validation, and error handling
- Demonstrate awareness of secure password practices
- Produce clear documentation and testing evidence

## 4. Project Description
SecurePass Toolkit allows the user to choose between two main options. The first option generates a secure password using a chosen length and selected character types such as uppercase letters, lowercase letters, numbers, and symbols. The second option checks the strength of a password and returns a score, rating, estimated entropy, and feedback for improvement.

The system was created using Python's standard library. The `secrets` module was used instead of `random` because it provides stronger security for password generation. Regular expressions were used to analyse password patterns and character variety.

## 5. Features Implemented
- Menu-based interface
- Secure password generation
- Password strength analysis
- Feedback messages to improve weak passwords
- Input validation and exception handling
- Unit testing

## 6. Testing Summary
The application was tested using Python's `unittest` module. Test cases checked the following:
- Passwords are generated at the requested length
- Generated passwords include the required character types
- Weak passwords are identified correctly
- Strong passwords are classified appropriately

## 7. Skills Developed
This project helped develop the following skills:
- Python programming
- Use of built-in libraries
- Writing test cases
- Problem solving and debugging
- Documentation and software presentation
- Basic understanding of cybersecurity good practice

## 8. Future Improvements
- Add a graphical user interface using Tkinter
- Save generated password reports to a file
- Add dictionary-based checks for compromised password patterns
- Allow export of analysis results

## 9. Conclusion
This project successfully meets the aim of building a small but useful Python application. It demonstrates practical programming ability and links directly to professional development by improving technical skills and promoting cybersecurity awareness.
