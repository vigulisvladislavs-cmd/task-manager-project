import unittest

from main import PasswordToolkit


class TestPasswordToolkit(unittest.TestCase):
    def setUp(self):
        self.toolkit = PasswordToolkit()

    def test_generate_password_length(self):
        password = self.toolkit.generate_password(length=16)
        self.assertEqual(len(password), 16)

    def test_generate_password_contains_required_categories(self):
        password = self.toolkit.generate_password(length=12)
        self.assertTrue(any(c.islower() for c in password))
        self.assertTrue(any(c.isupper() for c in password))
        self.assertTrue(any(c.isdigit() for c in password))
        self.assertTrue(any(not c.isalnum() for c in password))

    def test_check_strength_weak_password(self):
        result = self.toolkit.check_strength("password123")
        self.assertIn(result.rating, {"Very Weak", "Weak", "Moderate"})

    def test_check_strength_strong_password(self):
        result = self.toolkit.check_strength("A9#fL2@xQ7!m")
        self.assertIn(result.rating, {"Strong", "Very Strong"})


if __name__ == "__main__":
    unittest.main()
