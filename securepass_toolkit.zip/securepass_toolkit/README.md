# SecurePass Toolkit

## Overview
SecurePass Toolkit is a small Python command-line application that generates secure passwords and evaluates password strength. The project was designed to develop practical Python programming skills while also building awareness of cybersecurity best practices.

## Features
- Generate a secure password using custom settings
- Check the strength of an existing password
- Display a score, rating, entropy estimate, and improvement feedback
- Simple command-line menu system
- Unit tests included

## Technologies Used
- Python 3
- Standard library only (`secrets`, `string`, `math`, `re`, `unittest`)

## How to Run
1. Make sure Python 3 is installed.
2. Open a terminal in the project folder.
3. Run:

```bash
python main.py
```

## How to Run Tests
```bash
python -m unittest test_main.py
```

## Project Structure
- `main.py` – main application
- `test_main.py` – unit tests
- `README.md` – user documentation
- `report.md` – short report for submission

## Example Use Cases
- Creating stronger passwords for personal accounts
- Demonstrating Python programming skills in a portfolio
- Showing basic cybersecurity awareness in a mini project
